﻿using System;
using Shapes.Models;

namespace Shapes
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Circle circle = new Circle(10);
            //Rectangle rectangle = new Rectangle(10, 20);

            //circle.Draw();
            //rectangle.Draw();
        }
    }
}
